Liberation Sans Regular 1.05 editable source

Files reproduced from liberationfonts/liberation-1.7-fonts revision
99a390676af7be27fcb477c6636dd5106290dda4 (2009-01-12), trunk/:
https://github.com/liberationfonts/liberation-1.7-fonts/tree/99a390676af7be27fcb477c6636dd5106290dda4/trunk

Only the shipped Sans Regular face is included. With FontForge installed,
run from this directory:
  fontforge -script scripts/sfd2ttf.pe src/LiberationSans-Regular.sfd
This generates src/LiberationSans-Regular.ttf. The original Makefile is
included for reference (make build also builds the included SFD).
Excalidraw's distributed WOFF2 is a web-font conversion, copied unchanged
by Canvas. No font rebuild or WOFF2 encoder is added to the Canvas build.
See COPYING and License.txt for the original terms.
